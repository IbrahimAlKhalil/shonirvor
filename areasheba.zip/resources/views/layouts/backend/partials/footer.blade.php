    @yield('script')
    </body>
</html>