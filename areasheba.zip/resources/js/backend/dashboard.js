/***** CSS *****/
import './../../../node_modules/bootstrap/dist/css/bootstrap.css'; // Bootstrap CSS
import './../../sass/backend/components/_common.scss';

/***** JS *****/
import 'bootstrap'; // Bootstrap JS