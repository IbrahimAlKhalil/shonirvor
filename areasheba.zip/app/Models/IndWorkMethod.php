<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndWorkMethod extends Model
{
    protected $table = 'ind_work_method';
}
