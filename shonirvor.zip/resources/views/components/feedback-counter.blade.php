<div class="card">
    <div class="card-body">মন্তব্য দিয়েছে {{ en2bnNumber($countFeedbacks) }} জন</div>
</div>