@extends('layouts.frontend.master')

@section('title', 'Home')

@section('page-css')
    <style>
        .starter-template {
            padding: 3rem 1.5rem;
            text-align: center;
        }
    </style>
@endsection

@section('content')
    <main role="main" class="container">
        <div class="starter-template">
            <h1>Welcome to Shonirvor</h1>
            <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text
                and a mostly barebones HTML document.</p>
        </div>
    </main>
@endsection