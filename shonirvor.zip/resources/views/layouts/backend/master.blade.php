@include('layouts.backend.partials.head')
<body>
@include('layouts.backend.partials.header')
@yield('content')
@include('layouts.backend.partials.footer')