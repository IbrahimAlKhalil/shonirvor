<header>
    @include('layouts.frontend.partials.top-nav')
</header>