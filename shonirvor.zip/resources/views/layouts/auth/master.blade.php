@include('layouts.auth.partials.head')

@include('layouts.frontend.partials.header')
@yield('content')

@include('layouts.auth.partials.footer')
