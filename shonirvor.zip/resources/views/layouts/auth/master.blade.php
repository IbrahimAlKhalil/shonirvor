@include('layouts.auth.partials.head')

@include('layouts.frontend.partials.top-nav')
@yield('content')

@include('layouts.auth.partials.footer')
