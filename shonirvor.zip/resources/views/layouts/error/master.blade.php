@include('layouts.frontend.partials.head')

@include('layouts.error.partials.header')
@yield('content')