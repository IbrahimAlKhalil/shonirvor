<?php

return [

    'enabled' => env('SMS_ENABLED', false),

    'api' => env('SMS_API_KEY', ''),

    'senderid' => env('SMS_SENDERID', '')

];