<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Auth::routes();

Route::get('/', 'Frontend\HomeController@index')->name('frontend.home');
Route::get('dashboard', 'Backend\HomeController@index')->name('backend.home');

Route::resource('dashboard/dealer', 'Backend\DealerController');


/*** Ibrahim ***/

Route::resource('dealer-registration', 'Frontend\DealerRegistrationController', ['only' => ['index', 'store']]);

Route::get('dashboard/dealer-request/approve/{id}', 'Backend\DealerRequestController@approve')->name('dealer-request.approve');
Route::get('dashboard/dealer-request/reject/{id}', 'Backend\DealerRequestController@reject')->name('dealer-request.reject');
Route::resource('dashboard/dealer-request', 'Backend\DealerRequestController', ['only' => ['index', 'show']]);
