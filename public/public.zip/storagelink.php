<?php

symlink('/home/asianvisa/laravel/storage/app/public',
	'/home/asianvisa/public_html/storage');