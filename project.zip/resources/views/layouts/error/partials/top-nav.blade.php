<nav class="navbar navbar-dark" style="background-color: #008c73">
    <a class="navbar-brand" href="{{ route('home') }}">
        <img src="{{ asset('assets/images/logo.png') }}" style="width: 35px" alt="Logo">
        {{ config('app.name') }}
    </a>
</nav>