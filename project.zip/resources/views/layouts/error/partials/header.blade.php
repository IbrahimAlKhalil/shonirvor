<header>
    @include('layouts.error.partials.top-nav')
</header>