@include('layouts.backend.partials.head')

@include('layouts.backend.partials.header')
@yield('content')

@include('layouts.backend.partials.footer')