@include('layouts.frontend.partials.head')

<div class="main-container">
@include('layouts.frontend.partials.header')
@yield('content')

@include('layouts.frontend.partials.footer')